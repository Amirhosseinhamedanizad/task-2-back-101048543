const Employees = require('../models/employeeModel');

const addEmployee = async  (req,res) => {
    try {
        const {firstname, lastname, email} = req.body;
        if(!firstname){
            return res.status(401).json({message: 'First name required!'})
        }
        if(!lastname){
            return res.status(401).json({message: 'Last name required!'})
        }
        if(!email){
            return res.status(401).json({message: 'Email address required!'})
        }

        const isEmplyeeExist = await Employees.findOne({email:email});
        if(isEmplyeeExist){
            return res.status(403).json({message: 'Employee already exist!'})
        }

        await Employees.create({firstname,lastname,email})
        res.status(200).json({message: "Emplyee add successfully"})
    } catch (error) {
        res.status(500).json({message: 'Server error!'})
        console.log(error)
    }
}

module.exports = addEmployee;
